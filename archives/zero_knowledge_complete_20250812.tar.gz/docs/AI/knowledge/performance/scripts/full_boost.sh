#!/usr/bin/env bash
set -euo pipefail
bash /workspace/scripts/fast_env_boost.sh || true
bash /workspace/scripts/ultimate_speed.sh || true